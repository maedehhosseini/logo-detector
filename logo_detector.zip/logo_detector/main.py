from ultralytics import YOLO
import cv2
import matplotlib.pyplot as plt


model = YOLO("yolov8n.pt")  # مدل سبک اما سریع

# 2. بارگذاری تصویر
img_path = r"C:\Users\Asus\Desktop\logo_detector\b.png"
results = model(img_path)

# 3. نمایش نتیجه با bounding box
res_img = results[0].plot()  # رسم کادرهای شناسایی

# 4. نمایش تصویر با Matplotlib
plt.imshow(cv2.cvtColor(res_img, cv2.COLOR_BGR2RGB))
plt.axis("off")
plt.title("resulte (wthit YOLO)")
plt.show()





